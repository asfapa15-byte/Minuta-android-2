package ro.alex.minuta

import android.os.Bundle
import android.view.View
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class SettingsActivity : AppCompatActivity() {

    private lateinit var chatModel: TextInputEditText
    private lateinit var sttModel: TextInputEditText
    private var free = true

    // Model fields are kept per service, so switching doesn't mix them up.
    private val models = mutableMapOf<String, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val provider = findViewById<RadioGroup>(R.id.provider)
        val freeSection = findViewById<View>(R.id.free_section)
        val premiumSection = findViewById<View>(R.id.premium_section)
        val groq = findViewById<TextInputEditText>(R.id.groq_key)
        val anthropic = findViewById<TextInputEditText>(R.id.anthropic_key)
        val openai = findViewById<TextInputEditText>(R.id.openai_key)
        val context = findViewById<TextInputEditText>(R.id.context)
        val chatLayout = findViewById<TextInputLayout>(R.id.chat_model_layout)
        val sttLayout = findViewById<TextInputLayout>(R.id.stt_model_layout)
        chatModel = findViewById(R.id.chat_model)
        sttModel = findViewById(R.id.stt_model)

        for (k in listOf("groq_chat_model", "groq_stt_model", "claude_model", "stt_model")) {
            models[k] = Prefs.raw(this, k)
        }
        groq.setText(Prefs.groqKey(this))
        anthropic.setText(Prefs.anthropicKey(this))
        openai.setText(Prefs.openAiKey(this))
        context.setText(Prefs.context(this))

        fun show(isFree: Boolean) {
            free = isFree
            freeSection.visibility = if (isFree) View.VISIBLE else View.GONE
            premiumSection.visibility = if (isFree) View.GONE else View.VISIBLE
            chatLayout.helperText = "Implicit: " + if (isFree) Prefs.DEFAULT_GROQ_CHAT_MODEL else Prefs.DEFAULT_CLAUDE_MODEL
            sttLayout.helperText = "Implicit: " + if (isFree) Prefs.DEFAULT_GROQ_STT_MODEL else Prefs.DEFAULT_STT_MODEL
            chatModel.setText(models[if (isFree) "groq_chat_model" else "claude_model"].orEmpty())
            sttModel.setText(models[if (isFree) "groq_stt_model" else "stt_model"].orEmpty())
        }

        provider.check(if (Prefs.isFree(this)) R.id.provider_free else R.id.provider_premium)
        show(Prefs.isFree(this))
        provider.setOnCheckedChangeListener { _, checkedId ->
            rememberModels()
            show(checkedId == R.id.provider_free)
        }

        findViewById<MaterialButton>(R.id.save).setOnClickListener {
            rememberModels()
            val values = mutableMapOf(
                "provider" to if (free) Prefs.PROVIDER_FREE else Prefs.PROVIDER_PREMIUM,
                "groq_key" to groq.text?.toString().orEmpty(),
                "anthropic_key" to anthropic.text?.toString().orEmpty(),
                "openai_key" to openai.text?.toString().orEmpty(),
                "context" to context.text?.toString().orEmpty(),
            )
            values.putAll(models)
            Prefs.save(this, values)
            Toast.makeText(this, "Setările au fost salvate", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun rememberModels() {
        models[if (free) "groq_chat_model" else "claude_model"] = chatModel.text?.toString().orEmpty()
        models[if (free) "groq_stt_model" else "stt_model"] = sttModel.text?.toString().orEmpty()
    }
}
